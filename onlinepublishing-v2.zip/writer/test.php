<?php

echo $_POST['test'];

?>